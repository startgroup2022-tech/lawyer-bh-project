import { NextResponse } from "next/server";
import bcrypt from "bcryptjs";
import { eq } from "drizzle-orm";
import { db, schema } from "@/lib/db/client";
import { getAdminSession } from "@/lib/auth/admin-session";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

function isStrongPassword(password: string) {
  return (
    password.length >= 8 &&
    /[A-Z]/.test(password) &&
    /[a-z]/.test(password) &&
    /\d/.test(password)
  );
}

export async function PATCH(request: Request) {
  const session = await getAdminSession();

  if (!session) {
    return NextResponse.json(
      { ok: false, error: "Unauthorized" },
      { status: 401 },
    );
  }

  let body: {
    fullName?: string;
    password?: string;
  } = {};

  try {
    body = await request.json();
  } catch {
    body = {};
  }

  const fullName = String(body.fullName ?? "").trim();
  const password = String(body.password ?? "").trim();

  if (!fullName && !password) {
    return NextResponse.json(
      { ok: false, error: "Nothing to update" },
      { status: 400 },
    );
  }

  if (password && !isStrongPassword(password)) {
    return NextResponse.json(
      {
        ok: false,
        error:
          "Password must be at least 8 characters and include uppercase, lowercase, and a number",
      },
      { status: 400 },
    );
  }

  const values: {
    fullName?: string;
    passwordHash?: string;
    updatedAt: Date;
  } = {
    updatedAt: new Date(),
  };

  if (fullName) {
    values.fullName = fullName;
  }

  if (password) {
    values.passwordHash = await bcrypt.hash(password, 12);
  }

  const [updated] = await db
    .update(schema.adminUsers)
    .set(values)
    .where(eq(schema.adminUsers.id, session.id))
    .returning({
      id: schema.adminUsers.id,
      fullName: schema.adminUsers.fullName,
      email: schema.adminUsers.email,
      role: schema.adminUsers.role,
    });

  return NextResponse.json({
    ok: true,
    admin: updated,
  });
}