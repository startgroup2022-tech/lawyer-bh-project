import { NextResponse } from "next/server";
import { eq } from "drizzle-orm";
import { db, schema } from "@/lib/db/client";
import { getAdminSession } from "@/lib/auth/admin-session";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET() {
  const session = await getAdminSession();

  if (!session) {
    return NextResponse.json(
      { ok: false, error: "Unauthorized" },
      { status: 401 },
    );
  }

  const [admin] = await db
    .select({
      id: schema.adminUsers.id,
      fullName: schema.adminUsers.fullName,
      email: schema.adminUsers.email,
      role: schema.adminUsers.role,
      isActive: schema.adminUsers.isActive,
      lastLoginAt: schema.adminUsers.lastLoginAt,
      createdAt: schema.adminUsers.createdAt,
    })
    .from(schema.adminUsers)
    .where(eq(schema.adminUsers.id, session.id))
    .limit(1);

  if (!admin || !admin.isActive) {
    return NextResponse.json(
      { ok: false, error: "Unauthorized" },
      { status: 401 },
    );
  }

  return NextResponse.json({
    ok: true,
    admin,
  });
}