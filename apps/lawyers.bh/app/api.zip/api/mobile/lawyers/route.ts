import { NextResponse } from "next/server";
import { and, eq } from "drizzle-orm";
import { db, schema } from "@/lib/db/client";
import { getActiveCountry } from "@/lib/db/country-tables";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET(request: Request) {
  const url = new URL(request.url);
  const countryCode = (url.searchParams.get("countryCode") || "BH")
    .trim()
    .toUpperCase();

  const country = await getActiveCountry(countryCode);

  if (!country) {
    return NextResponse.json(
      { ok: false, error: "Country is not active" },
      { status: 400 },
    );
  }

  // bahrain_lawyers is the inheritance parent, so it can query every child
  // country table. The country_code condition keeps this response isolated.
  const lawyers = await db
    .select({
      id: schema.bahrainLawyers.id,
      countryCode: schema.bahrainLawyers.countryCode,
      fullNameAr: schema.bahrainLawyers.fullNameAr,
      fullNameEn: schema.bahrainLawyers.fullNameEn,
      phone: schema.bahrainLawyers.phone,
      email: schema.bahrainLawyers.email,
      status: schema.bahrainLawyers.status,
      subscriptionType: schema.bahrainLawyers.subscriptionType,
    })
    .from(schema.bahrainLawyers)
    .where(
      and(
        eq(schema.bahrainLawyers.countryCode, country.code),
        eq(schema.bahrainLawyers.status, "approved"),
        eq(schema.bahrainLawyers.isActive, true),
      ),
    );

  return NextResponse.json({
    ok: true,
    countryCode: country.code,
    data: lawyers,
  });
}
