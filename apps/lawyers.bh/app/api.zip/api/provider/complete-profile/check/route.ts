import { NextResponse } from "next/server";
import { eq } from "drizzle-orm";
import { db, schema } from "@/lib/db/client";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function POST(request: Request) {
  let body: { token?: string } = {};

  try {
    body = await request.json();
  } catch {
    body = {};
  }

  const token = String(body.token ?? "").trim();

  if (!token) {
    return NextResponse.json(
      { ok: false, error: "Token is required" },
      { status: 400 },
    );
  }

  const [lawyer] = await db
    .select({
      id: schema.bahrainLawyers.id,
      countryCode: schema.bahrainLawyers.countryCode,

      fullNameAr: schema.bahrainLawyers.fullNameAr,
      fullNameEn: schema.bahrainLawyers.fullNameEn,
      email: schema.bahrainLawyers.email,
      phone: schema.bahrainLawyers.phone,

      registrationNo: schema.bahrainLawyers.registrationNo,
      registrationLevel: schema.bahrainLawyers.registrationLevel,
      experienceYears: schema.bahrainLawyers.experienceYears,
      language: schema.bahrainLawyers.language,
      workingHours: schema.bahrainLawyers.workingHours,

      specialtyMain: schema.bahrainLawyers.specialtyMain,
      specialtySubs: schema.bahrainLawyers.specialtySubs,
      specialties: schema.bahrainLawyers.specialties,

      licenseExpiryDate: schema.bahrainLawyers.licenseExpiryDate,

      profileImageFileName: schema.bahrainLawyers.profileImageFileName,
      profileImageMimeType: schema.bahrainLawyers.profileImageMimeType,
      profileImageBase64: schema.bahrainLawyers.profileImageBase64,

      licenseFileName: schema.bahrainLawyers.licenseFileName,
      licenseFileMimeType: schema.bahrainLawyers.licenseFileMimeType,
      licenseFileBase64: schema.bahrainLawyers.licenseFileBase64,

      signatureDataUrl: schema.bahrainLawyers.signatureDataUrl,
      agreementAccepted: schema.bahrainLawyers.agreementAccepted,

      profileCompleted: schema.bahrainLawyers.profileCompleted,
      inviteTokenExpiresAt: schema.bahrainLawyers.inviteTokenExpiresAt,
    })
    .from(schema.bahrainLawyers)
    .where(eq(schema.bahrainLawyers.inviteToken, token))
    .limit(1);

  if (!lawyer) {
    return NextResponse.json(
      { ok: false, error: "Invalid invitation link" },
      { status: 404 },
    );
  }

  if (lawyer.profileCompleted) {
    return NextResponse.json(
      { ok: false, error: "Profile already completed" },
      { status: 409 },
    );
  }

  if (
    lawyer.inviteTokenExpiresAt &&
    new Date(lawyer.inviteTokenExpiresAt).getTime() < Date.now()
  ) {
    return NextResponse.json(
      { ok: false, error: "Invitation link expired" },
      { status: 410 },
    );
  }

  const profileImagePreview =
    lawyer.profileImageBase64 && lawyer.profileImageMimeType
      ? `data:${lawyer.profileImageMimeType};base64,${lawyer.profileImageBase64}`
      : "";

  const licenseFilePreview =
    lawyer.licenseFileBase64 && lawyer.licenseFileMimeType
      ? `data:${lawyer.licenseFileMimeType};base64,${lawyer.licenseFileBase64}`
      : "";

  const specialtiesData = lawyer.specialties as
    | {
        main?: string;
        subs?: string[];
      }
    | null
    | undefined;

  const specialtyMain = lawyer.specialtyMain || specialtiesData?.main || "";

  const specialtySubs =
    Array.isArray(lawyer.specialtySubs) && lawyer.specialtySubs.length > 0
      ? lawyer.specialtySubs
      : Array.isArray(specialtiesData?.subs)
        ? specialtiesData.subs
        : [];

  const hasSignature = Boolean(
    lawyer.signatureDataUrl && lawyer.signatureDataUrl.trim(),
  );

  const signedAgreementUrl = hasSignature
    ? `/api/provider/signed-agreement?id=${encodeURIComponent(lawyer.id)}`
    : "";

  return NextResponse.json({
    ok: true,
    lawyer: {
      id: lawyer.id,

      fullNameAr: lawyer.fullNameAr ?? "",
      fullNameEn: lawyer.fullNameEn ?? "",
      email: lawyer.email ?? "",
      phone: lawyer.phone ?? "",

      registrationNo:
        lawyer.registrationNo && lawyer.registrationNo.startsWith("INV-")
          ? ""
          : lawyer.registrationNo ?? "",

      registrationLevel: lawyer.registrationLevel ?? "",
      experienceYears: lawyer.experienceYears ?? 0,
      language: lawyer.language ?? "",
      workingHours: lawyer.workingHours ?? "",

      specialtyMain,
      specialtySubs,

      licenseExpiryDate: lawyer.licenseExpiryDate ?? "",

      profileImageFileName: lawyer.profileImageFileName ?? "",
      profileImageMimeType: lawyer.profileImageMimeType ?? "",
      profileImagePreview,

      licenseFileName: lawyer.licenseFileName ?? "",
      licenseFileMimeType: lawyer.licenseFileMimeType ?? "",
      licenseFilePreview,

      signatureDataUrl: lawyer.signatureDataUrl ?? "",
      hasSignature,
      agreementAccepted: Boolean(lawyer.agreementAccepted),
      signedAgreementUrl,
    },
  });
}