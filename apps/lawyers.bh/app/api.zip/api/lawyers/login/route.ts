import { NextResponse } from "next/server";
import bcrypt from "bcryptjs";
import { and, eq } from "drizzle-orm";
import { db, schema } from "@/lib/db/client";
import { getActiveCountry } from "@/lib/db/country-tables";
import { createMobileLawyerToken } from "@/lib/mobile-lawyer-auth";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

function mobileStatus(status: string) {
  return status === "pending" ? "pending_review" : status;
}

export async function POST(request: Request) {
  const body = (await request.json().catch(() => null)) as
    | { licenseNumber?: string; password?: string; countryCode?: string }
    | null;

  const licenseNumber = String(body?.licenseNumber || "").trim();
  const password = String(body?.password || "");
  const country = await getActiveCountry(body?.countryCode || "BH");

  if (!country) {
    return NextResponse.json(
      { success: false, message: "Country is not active" },
      { status: 400 },
    );
  }

  if (!licenseNumber || !password) {
    return NextResponse.json(
      { success: false, message: "License number and password are required" },
      { status: 400 },
    );
  }

  const [lawyer] = await db
    .select({
      id: schema.bahrainLawyers.id,
      countryCode: schema.bahrainLawyers.countryCode,
      registrationNo: schema.bahrainLawyers.registrationNo,
      passwordHash: schema.bahrainLawyers.passwordHash,
      status: schema.bahrainLawyers.status,
      isActive: schema.bahrainLawyers.isActive,
      isEmergencyReady: schema.bahrainLawyers.isEmergencyReady,
      phone: schema.bahrainLawyers.phone,
    })
    .from(schema.bahrainLawyers)
    .where(
      and(
        eq(schema.bahrainLawyers.countryCode, country.code),
        eq(schema.bahrainLawyers.registrationNo, licenseNumber),
      ),
    )
    .limit(1);

  if (!lawyer?.passwordHash || !(await bcrypt.compare(password, lawyer.passwordHash))) {
    return NextResponse.json(
      { success: false, message: "Invalid login details" },
      { status: 401 },
    );
  }

  if (lawyer.status === "rejected" || lawyer.status === "suspended") {
    return NextResponse.json(
      { success: false, message: "Account is not available" },
      { status: 403 },
    );
  }

  const token = createMobileLawyerToken(lawyer.id, lawyer.countryCode);

  return NextResponse.json({
    success: true,
    data: {
      id: lawyer.id,
      countryCode: lawyer.countryCode,
      licenseNumber: lawyer.registrationNo,
      phone: lawyer.phone,
      status: mobileStatus(lawyer.status),
      isAvailable: lawyer.isActive && lawyer.isEmergencyReady,
      token,
    },
  });
}
